
import React, { createContext, useContext, useState } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const savedUser = localStorage.getItem('user');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  const [contentData, setContentData] = useState(() => {
    const savedData = localStorage.getItem('contentData');
    return savedData ? JSON.parse(savedData) : {
      negocios: [],
      restaurantes: [],
      sitiosTuristicos: [],
      guias: [],
      hoteles: [],
      transporte: [],
      posts: []
    };
  });

  const register = (username, password, categoria) => {
    const existingUsers = JSON.parse(localStorage.getItem('users') || '[]');
    if (existingUsers.find(u => u.username === username)) {
      return { success: false, message: 'El usuario ya existe' };
    }

    const userData = {
      username,
      role: 'user',
      categoria,
      createdAt: new Date().toISOString(),
      status: 'pendiente'
    };

    existingUsers.push(userData);
    localStorage.setItem('users', JSON.stringify(existingUsers));
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
    return { success: true };
  };

  const login = (username, password) => {
    if (username === 'admin' && password === 'admin') {
      const userData = {
        username,
        role: 'admin',
        createdAt: new Date().toISOString()
      };
      setUser(userData);
      localStorage.setItem('user', JSON.stringify(userData));
      return { success: true };
    }

    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const foundUser = users.find(u => u.username === username);
    
    if (foundUser) {
      setUser(foundUser);
      localStorage.setItem('user', JSON.stringify(foundUser));
      return { success: true };
    }

    return { success: false, message: 'Usuario o contraseña incorrectos' };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const addContent = (category, data) => {
    const newContentData = {
      ...contentData,
      [category]: [...contentData[category], { 
        ...data, 
        id: Date.now(), 
        status: 'pendiente',
        username: user.username,
        createdAt: new Date().toISOString()
      }]
    };
    setContentData(newContentData);
    localStorage.setItem('contentData', JSON.stringify(newContentData));
    return true;
  };

  const updateContent = (category, id, data) => {
    const newContentData = {
      ...contentData,
      [category]: contentData[category].map(item =>
        item.id === id ? { ...item, ...data } : item
      )
    };
    setContentData(newContentData);
    localStorage.setItem('contentData', JSON.stringify(newContentData));
    return true;
  };

  const deleteContent = (category, id) => {
    const newContentData = {
      ...contentData,
      [category]: contentData[category].filter(item => item.id !== id)
    };
    setContentData(newContentData);
    localStorage.setItem('contentData', JSON.stringify(newContentData));
    return true;
  };

  const approveContent = (category, id) => {
    const newContentData = {
      ...contentData,
      [category]: contentData[category].map(item =>
        item.id === id ? { ...item, status: 'aprobado' } : item
      )
    };
    setContentData(newContentData);
    localStorage.setItem('contentData', JSON.stringify(newContentData));
    return true;
  };

  const addPost = (data) => {
    return addContent('posts', {
      ...data,
      likes: 0,
      comments: []
    });
  };

  const getUserContent = (username, category) => {
    return contentData[category].filter(item => item.username === username);
  };

  const getApprovedContent = (category) => {
    return contentData[category].filter(item => item.status === 'aprobado');
  };

  const getPendingContent = (category) => {
    return contentData[category].filter(item => item.status === 'pendiente');
  };

  const approveUser = (username) => {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const updatedUsers = users.map(u => 
      u.username === username ? { ...u, status: 'aprobado' } : u
    );
    localStorage.setItem('users', JSON.stringify(updatedUsers));

    if (user?.username === username) {
      const updatedUser = { ...user, status: 'aprobado' };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
    }
  };

  const getAllUsers = () => {
    return JSON.parse(localStorage.getItem('users') || '[]');
  };

  return (
    <AuthContext.Provider value={{ 
      user,
      login,
      register,
      logout,
      addContent,
      updateContent,
      deleteContent,
      approveContent,
      addPost,
      getUserContent,
      getApprovedContent,
      getPendingContent,
      approveUser,
      getAllUsers,
      contentData
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth debe ser usado dentro de un AuthProvider');
  }
  return context;
};
