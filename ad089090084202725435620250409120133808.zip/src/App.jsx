
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import Navbar from '@/components/Navbar';
import Home from '@/pages/Home';
import Negocios from '@/pages/Negocios';
import Restaurantes from '@/pages/Restaurantes';
import SitiosTuristicos from '@/pages/SitiosTuristicos';
import GuiasLocales from '@/pages/GuiasLocales';
import Hoteles from '@/pages/Hoteles';
import Transporte from '@/pages/Transporte';
import Login from '@/pages/Login';
import Admin from '@/pages/Admin';
import UserPanel from '@/pages/UserPanel';
import { AuthProvider } from '@/contexts/AuthContext';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-background">
          <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/negocios" element={<Negocios />} />
            <Route path="/restaurantes" element={<Restaurantes />} />
            <Route path="/sitios-turisticos" element={<SitiosTuristicos />} />
            <Route path="/guias-locales" element={<GuiasLocales />} />
            <Route path="/hoteles" element={<Hoteles />} />
            <Route path="/transporte" element={<Transporte />} />
            <Route path="/login" element={<Login />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="/panel" element={<UserPanel />} />
          </Routes>
          <Toaster />
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
