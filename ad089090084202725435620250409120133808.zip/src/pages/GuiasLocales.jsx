
import React from 'react';
import { motion } from 'framer-motion';

const GuiasLocales = () => {
  const guias = [
    {
      nombre: "Carlos Ramírez",
      servicios: ["Senderismo", "Avistamiento de aves", "Historia local"],
      telefono: "604-789-0123",
      experiencia: "10 años como guía local"
    },
    {
      nombre: "Ana María López",
      servicios: ["Turismo de aventura", "Fotografía", "Rutas ecológicas"],
      telefono: "604-890-1234",
      experiencia: "8 años como guía certificada"
    },
    {
      nombre: "Juan Pablo Mejía",
      servicios: ["Tours culturales", "Gastronomía local", "Artesanías"],
      telefono: "604-901-2345",
      experiencia: "12 años en turismo local"
    }
  ];

  return (
    <div className="container mx-auto py-8 px-4">
      <motion.h1 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-3xl font-bold mb-8 text-center"
      >
        Guías Locales de San Luis
      </motion.h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {guias.map((guia, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-lg shadow-lg p-6"
          >
            <div className="mb-4">
              <img  
                className="w-32 h-32 rounded-full mx-auto object-cover" 
                alt={`Guía ${guia.nombre}`}
               src="https://images.unsplash.com/photo-1581326002021-ba3f4abd127e" />
            </div>
            <h2 className="text-xl font-semibold text-center mb-4">{guia.nombre}</h2>
            <p className="text-gray-600 text-center mb-4">{guia.experiencia}</p>
            <div className="mb-4">
              <h3 className="font-semibold mb-2">Servicios:</h3>
              <ul className="list-disc list-inside text-gray-600">
                {guia.servicios.map((servicio, sIndex) => (
                  <li key={sIndex}>{servicio}</li>
                ))}
              </ul>
            </div>
            <div className="text-center">
              <p className="text-gray-600">
                <strong>Contacto:</strong> {guia.telefono}
              </p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default GuiasLocales;
