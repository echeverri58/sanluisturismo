
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const UserPanel = () => {
  const { user, getUserData, updateUserData } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    nombre: '',
    direccion: '',
    telefono: '',
    correo: '',
    descripcion: '',
    imagenes: [],
    videoUrl: '',
    servicios: '',
    horarios: '',
    precios: ''
  });

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    const data = getUserData();
    if (data) {
      setFormData(data);
    }
  }, [user, navigate]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (updateUserData(formData)) {
      toast({
        title: "¡Éxito!",
        description: "Tu información ha sido actualizada.",
      });
    }
  };

  const renderFields = () => {
    const commonFields = (
      <>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Nombre</label>
            <input
              type="text"
              value={formData.nombre}
              onChange={(e) => setFormData({...formData, nombre: e.target.value})}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Dirección</label>
            <input
              type="text"
              value={formData.direccion}
              onChange={(e) => setFormData({...formData, direccion: e.target.value})}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Teléfono</label>
            <input
              type="text"
              value={formData.telefono}
              onChange={(e) => setFormData({...formData, telefono: e.target.value})}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Correo</label>
            <input
              type="email"
              value={formData.correo}
              onChange={(e) => setFormData({...formData, correo: e.target.value})}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">URL del Video (YouTube)</label>
            <input
              type="text"
              value={formData.videoUrl}
              onChange={(e) => setFormData({...formData, videoUrl: e.target.value})}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
              placeholder="https://youtube.com/watch?v=..."
            />
          </div>
        </div>
      </>
    );

    const categorySpecificFields = {
      restaurante: (
        <div className="space-y-4 mt-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Menú</label>
            <textarea
              value={formData.menu}
              onChange={(e) => setFormData({...formData, menu: e.target.value})}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
              rows="4"
              placeholder="Describe tu menú..."
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Horarios</label>
            <textarea
              value={formData.horarios}
              onChange={(e) => setFormData({...formData, horarios: e.target.value})}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
              rows="2"
            />
          </div>
        </div>
      ),
      hotel: (
        <div className="space-y-4 mt-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Comodidades</label>
            <textarea
              value={formData.comodidades}
              onChange={(e) => setFormData({...formData, comodidades: e.target.value})}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
              rows="4"
              placeholder="Lista las comodidades..."
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Precios</label>
            <textarea
              value={formData.precios}
              onChange={(e) => setFormData({...formData, precios: e.target.value})}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
              rows="2"
            />
          </div>
        </div>
      ),
      guia: (
        <div className="space-y-4 mt-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Servicios</label>
            <textarea
              value={formData.servicios}
              onChange={(e) => setFormData({...formData, servicios: e.target.value})}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
              rows="4"
              placeholder="Lista tus servicios..."
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Experiencia</label>
            <textarea
              value={formData.experiencia}
              onChange={(e) => setFormData({...formData, experiencia: e.target.value})}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
              rows="2"
            />
          </div>
        </div>
      ),
      transporte: (
        <div className="space-y-4 mt-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Rutas y Destinos</label>
            <textarea
              value={formData.rutas}
              onChange={(e) => setFormData({...formData, rutas: e.target.value})}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
              rows="4"
              placeholder="Describe tus rutas..."
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Horarios</label>
            <textarea
              value={formData.horarios}
              onChange={(e) => setFormData({...formData, horarios: e.target.value})}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
              rows="2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Tarifas</label>
            <textarea
              value={formData.tarifas}
              onChange={(e) => setFormData({...formData, tarifas: e.target.value})}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
              rows="2"
            />
          </div>
        </div>
      )
    };

    return (
      <>
        {commonFields}
        {categorySpecificFields[user?.categoria]}
      </>
    );
  };

  if (!user) return null;

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Mi Panel</h1>
        
        {user.status === 'pendiente' && (
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6">
            <div className="flex">
              <div className="flex-shrink-0">
                <svg className="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
              </div>
              <div className="ml-3">
                <p className="text-sm text-yellow-700">
                  Tu cuenta está pendiente de aprobación por el administrador.
                </p>
              </div>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6 bg-white shadow-lg rounded-lg p-6">
          {renderFields()}
          
          <div className="mt-6">
            <Button 
              type="submit" 
              className="w-full bg-emerald-600 hover:bg-emerald-700"
              disabled={user.status === 'pendiente'}
            >
              Guardar Cambios
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default UserPanel;
