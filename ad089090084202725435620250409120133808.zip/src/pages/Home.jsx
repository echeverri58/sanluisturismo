
import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';

const Home = () => {
  const { user, contentData, addPost } = useAuth();
  const { toast } = useToast();
  const [newPost, setNewPost] = React.useState({
    titulo: '',
    contenido: '',
    imagen: ''
  });

  const handleSubmitPost = (e) => {
    e.preventDefault();
    if (addPost(newPost)) {
      toast({
        title: "¡Éxito!",
        description: "Tu publicación ha sido enviada para aprobación.",
      });
      setNewPost({ titulo: '', contenido: '', imagen: '' });
    }
  };

  const approvedPosts = contentData.posts.filter(post => post.status === 'aprobado')
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  return (
    <div className="min-h-screen">
      <div className="hero-pattern">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-5xl font-bold text-gray-900 mb-6">
              Bienvenido a San Luis Antioquia
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Descubre la magia de nuestro municipio, su gente y sus lugares
            </p>
          </motion.div>

          {user && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="max-w-2xl mx-auto mb-12 bg-white p-6 rounded-lg shadow-lg"
            >
              <h2 className="text-2xl font-semibold mb-4">Crear Nueva Publicación</h2>
              <form onSubmit={handleSubmitPost} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Título</label>
                  <input
                    type="text"
                    value={newPost.titulo}
                    onChange={(e) => setNewPost({...newPost, titulo: e.target.value})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Contenido</label>
                  <textarea
                    value={newPost.contenido}
                    onChange={(e) => setNewPost({...newPost, contenido: e.target.value})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                    rows="4"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">URL de la imagen</label>
                  <input
                    type="text"
                    value={newPost.imagen}
                    onChange={(e) => setNewPost({...newPost, imagen: e.target.value})}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                  />
                </div>
                <Button type="submit" className="w-full">Publicar</Button>
              </form>
            </motion.div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            {approvedPosts.map((post, index) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white rounded-lg shadow-lg overflow-hidden"
              >
                {post.imagen && (
                  <img
                    src={post.imagen}
                    alt={post.titulo}
                    className="w-full h-48 object-cover"
                  />
                )}
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{post.titulo}</h3>
                  <p className="text-gray-600 mb-4">{post.contenido}</p>
                  <div className="text-sm text-gray-500">
                    Publicado por {post.username} el {new Date(post.createdAt).toLocaleDateString()}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-white rounded-lg shadow-lg p-6"
            >
              <img  alt="Paisaje de San Luis" className="w-full h-48 object-cover rounded-lg mb-4" src="https://images.unsplash.com/photo-1600791833083-8caba2c4c5e0" />
              <h3 className="text-xl font-semibold mb-2">Naturaleza Extraordinaria</h3>
              <p className="text-gray-600 mb-4">
                Explora nuestros hermosos paisajes y sitios naturales
              </p>
              <Link to="/sitios-turisticos">
                <Button className="w-full">Descubrir</Button>
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-white rounded-lg shadow-lg p-6"
            >
              <img  alt="Gastronomía local" className="w-full h-48 object-cover rounded-lg mb-4" src="https://images.unsplash.com/photo-1600147421674-6db89d41ffb0" />
              <h3 className="text-xl font-semibold mb-2">Gastronomía Local</h3>
              <p className="text-gray-600 mb-4">
                Disfruta de nuestra deliciosa cocina tradicional
              </p>
              <Link to="/restaurantes">
                <Button className="w-full">Explorar</Button>
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="bg-white rounded-lg shadow-lg p-6"
            >
              <img  alt="Cultura y tradiciones" className="w-full h-48 object-cover rounded-lg mb-4" src="https://images.unsplash.com/photo-1670948540770-841ec15f0ef0" />
              <h3 className="text-xl font-semibold mb-2">Cultura y Tradiciones</h3>
              <p className="text-gray-600 mb-4">
                Conoce nuestra rica historia y tradiciones
              </p>
              <Link to="/guias-locales">
                <Button className="w-full">Conocer más</Button>
              </Link>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
