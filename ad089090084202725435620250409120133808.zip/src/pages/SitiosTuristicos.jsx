
import React from 'react';
import { motion } from 'framer-motion';

const SitiosTuristicos = () => {
  const sitios = [
    {
      nombre: "Cascada El Paraíso",
      descripcion: "Una hermosa caída de agua de 20 metros rodeada de vegetación nativa. Ideal para practicar senderismo y fotografía.",
      ubicacion: "A 3 km del casco urbano por la vía hacia El Carmen"
    },
    {
      nombre: "Mirador San Luis",
      descripcion: "Punto panorámico que ofrece una vista espectacular del municipio y sus alrededores. Perfecto para ver el atardecer.",
      ubicacion: "Cerro La Cruz, acceso por sendero peatonal"
    },
    {
      nombre: "Parque Ecológico",
      descripcion: "Espacio natural con senderos interpretativos, avistamiento de aves y zona de picnic.",
      ubicacion: "Vereda El Porvenir, a 2 km del parque principal"
    }
  ];

  return (
    <div className="container mx-auto py-8 px-4">
      <motion.h1 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-3xl font-bold mb-8 text-center"
      >
        Sitios Turísticos de San Luis
      </motion.h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {sitios.map((sitio, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-lg shadow-lg overflow-hidden"
          >
            <div className="relative h-64">
              <img  
                className="w-full h-full object-cover" 
                alt={sitio.nombre}
               src="https://images.unsplash.com/photo-1623849329184-ab2f5a659b19" />
            </div>
            <div className="p-6">
              <h2 className="text-2xl font-bold mb-3">{sitio.nombre}</h2>
              <p className="text-gray-600 mb-4">{sitio.descripcion}</p>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-semibold text-gray-700 mb-2">Ubicación:</h3>
                <p className="text-gray-600">{sitio.ubicacion}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default SitiosTuristicos;
