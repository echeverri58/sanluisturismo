
import React from 'react';
import { motion } from 'framer-motion';

const Negocios = () => {
  const negocios = [
    {
      nombre: "Tienda Don Pedro",
      direccion: "Calle Principal #123",
      servicio: "Abarrotes y víveres",
      telefono: "604-123-4567",
      correo: "tiendadonpedro@email.com"
    },
    {
      nombre: "Artesanías San Luis",
      direccion: "Plaza Central #45",
      servicio: "Artesanías locales",
      telefono: "604-234-5678",
      correo: "artesaniassanluis@email.com"
    }
  ];

  return (
    <div className="container mx-auto py-8 px-4">
      <motion.h1 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-3xl font-bold mb-8 text-center"
      >
        Negocios en San Luis
      </motion.h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {negocios.map((negocio, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-lg shadow-lg p-6"
          >
            <div className="mb-4">
              <img  
                className="w-full h-48 object-cover rounded-lg" 
                alt={`Imagen de ${negocio.nombre}`}
               src="https://images.unsplash.com/photo-1694211962257-81690081b9b7" />
            </div>
            <h2 className="text-xl font-semibold mb-2">{negocio.nombre}</h2>
            <p className="text-gray-600 mb-2">
              <strong>Dirección:</strong> {negocio.direccion}
            </p>
            <p className="text-gray-600 mb-2">
              <strong>Servicio:</strong> {negocio.servicio}
            </p>
            <p className="text-gray-600 mb-2">
              <strong>Teléfono:</strong> {negocio.telefono}
            </p>
            <p className="text-gray-600">
              <strong>Correo:</strong> {negocio.correo}
            </p>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default Negocios;
