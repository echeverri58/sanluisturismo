
import React from 'react';
import { motion } from 'framer-motion';

const Hoteles = () => {
  const hoteles = [
    {
      nombre: "Hotel San Luis Real",
      comodidades: [
        "WiFi gratis",
        "Desayuno incluido",
        "Aire acondicionado",
        "Estacionamiento"
      ],
      telefono: "604-123-4567",
      direccion: "Calle Principal #45-67"
    },
    {
      nombre: "Posada del Río",
      comodidades: [
        "Piscina",
        "Restaurante",
        "Jardines",
        "TV por cable"
      ],
      telefono: "604-234-5678",
      direccion: "Carrera 15 #30-45"
    },
    {
      nombre: "Hospedaje El Descanso",
      comodidades: [
        "Habitaciones familiares",
        "Cocina compartida",
        "Terraza",
        "WiFi"
      ],
      telefono: "604-345-6789",
      direccion: "Avenida Central #20-30"
    }
  ];

  return (
    <div className="container mx-auto py-8 px-4">
      <motion.h1 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-3xl font-bold mb-8 text-center"
      >
        Hoteles en San Luis
      </motion.h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {hoteles.map((hotel, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-lg shadow-lg overflow-hidden"
          >
            <div className="relative h-64">
              <img  
                className="w-full h-full object-cover" 
                alt={`Hotel ${hotel.nombre}`}
               src="https://images.unsplash.com/photo-1591502801938-635027395527" />
            </div>
            <div className="p-6">
              <h2 className="text-2xl font-bold mb-4">{hotel.nombre}</h2>
              <div className="mb-4">
                <h3 className="font-semibold mb-2">Comodidades:</h3>
                <ul className="grid grid-cols-2 gap-2">
                  {hotel.comodidades.map((comodidad, cIndex) => (
                    <li key={cIndex} className="text-gray-600 flex items-center">
                      <span className="w-2 h-2 bg-primary rounded-full mr-2"></span>
                      {comodidad}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="mt-4 pt-4 border-t border-gray-200">
                <p className="text-gray-600 mb-2">
                  <strong>Teléfono:</strong> {hotel.telefono}
                </p>
                <p className="text-gray-600">
                  <strong>Dirección:</strong> {hotel.direccion}
                </p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default Hoteles;
