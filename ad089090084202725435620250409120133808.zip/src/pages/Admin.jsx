
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';

const Admin = () => {
  const { user, contentData, approveContent, deleteContent, getAllUsers, approveUser } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('negocios');

  React.useEffect(() => {
    if (!user || user.role !== 'admin') {
      navigate('/login');
    }
  }, [user, navigate]);

  const handleApprove = (category, id) => {
    if (approveContent(category, id)) {
      toast({
        title: "¡Éxito!",
        description: "Contenido aprobado correctamente.",
      });
    }
  };

  const handleDelete = (category, id) => {
    if (deleteContent(category, id)) {
      toast({
        title: "¡Éxito!",
        description: "Contenido eliminado correctamente.",
      });
    }
  };

  const handleApproveUser = (username) => {
    approveUser(username);
    toast({
      title: "¡Éxito!",
      description: "Usuario aprobado correctamente.",
    });
  };

  const renderContent = (category) => {
    const items = contentData[category] || [];
    
    return (
      <div className="space-y-4">
        {items.map((item) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-4 rounded-lg shadow"
          >
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-lg font-semibold">{item.nombre}</h3>
                <p className="text-gray-600">{item.descripcion}</p>
                {/* Mostrar campos específicos según la categoría */}
                {category === 'restaurantes' && (
                  <div className="mt-2">
                    <p><strong>Menú:</strong> {item.menu}</p>
                    <p><strong>Horarios:</strong> {item.horarios}</p>
                  </div>
                )}
                {category === 'hoteles' && (
                  <div className="mt-2">
                    <p><strong>Comodidades:</strong> {item.comodidades}</p>
                    <p><strong>Precios:</strong> {item.precios}</p>
                  </div>
                )}
                <p className="mt-2 text-sm text-gray-500">
                  Estado: <span className={`font-semibold ${item.status === 'aprobado' ? 'text-green-600' : 'text-yellow-600'}`}>
                    {item.status === 'aprobado' ? 'Aprobado' : 'Pendiente'}
                  </span>
                </p>
              </div>
              <div className="space-x-2">
                {item.status !== 'aprobado' && (
                  <Button
                    onClick={() => handleApprove(category, item.id)}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Aprobar
                  </Button>
                )}
                <Button
                  onClick={() => handleDelete(category, item.id)}
                  variant="destructive"
                >
                  Eliminar
                </Button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    );
  };

  const renderUsers = () => {
    const users = getAllUsers();
    
    return (
      <div className="space-y-4">
        {users.map((user, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-4 rounded-lg shadow"
          >
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-lg font-semibold">{user.username}</h3>
                <p className="text-gray-600">Categoría: {user.categoria}</p>
                <p className="text-gray-600">
                  Estado: <span className={user.status === 'aprobado' ? 'text-green-600' : 'text-yellow-600'}>
                    {user.status}
                  </span>
                </p>
              </div>
              {user.status !== 'aprobado' && (
                <Button
                  onClick={() => handleApproveUser(user.username)}
                  className="bg-green-600 hover:bg-green-700"
                >
                  Aprobar Usuario
                </Button>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    );
  };

  if (!user || user.role !== 'admin') {
    return null;
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-8">Panel de Administración</h1>
      
      <Tabs defaultValue="negocios" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-7">
          <TabsTrigger value="negocios">Negocios</TabsTrigger>
          <TabsTrigger value="restaurantes">Restaurantes</TabsTrigger>
          <TabsTrigger value="sitiosTuristicos">Sitios</TabsTrigger>
          <TabsTrigger value="guias">Guías</TabsTrigger>
          <TabsTrigger value="hoteles">Hoteles</TabsTrigger>
          <TabsTrigger value="transporte">Transporte</TabsTrigger>
          <TabsTrigger value="usuarios">Usuarios</TabsTrigger>
        </TabsList>

        <div className="mt-6">
          <TabsContent value="negocios">
            {renderContent('negocios')}
          </TabsContent>
          <TabsContent value="restaurantes">
            {renderContent('restaurantes')}
          </TabsContent>
          <TabsContent value="sitiosTuristicos">
            {renderContent('sitiosTuristicos')}
          </TabsContent>
          <TabsContent value="guias">
            {renderContent('guias')}
          </TabsContent>
          <TabsContent value="hoteles">
            {renderContent('hoteles')}
          </TabsContent>
          <TabsContent value="transporte">
            {renderContent('transporte')}
          </TabsContent>
          <TabsContent value="usuarios">
            {renderUsers()}
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
};

export default Admin;
