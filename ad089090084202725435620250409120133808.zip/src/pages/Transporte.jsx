
import React from 'react';
import { motion } from 'framer-motion';

const Transporte = () => {
  const rutas = [
    {
      empresa: "Transportes San Luis Express",
      contacto: "604-567-8901",
      horarios: [
        "Lunes a Viernes: 5:00 AM - 8:00 PM",
        "Sábados y Domingos: 6:00 AM - 7:00 PM"
      ],
      valor: "25.000",
      destinos: ["Medellín", "Rionegro", "Marinilla"]
    },
    {
      empresa: "Cootrasal",
      contacto: "604-678-9012",
      horarios: [
        "Lunes a Domingo: 4:30 AM - 7:30 PM"
      ],
      valor: "20.000",
      destinos: ["Puerto Triunfo", "Doradal", "La Danta"]
    },
    {
      empresa: "Transportes del Oriente",
      contacto: "604-789-0123",
      horarios: [
        "Lunes a Sábado: 5:30 AM - 6:30 PM",
        "Domingos: 6:30 AM - 5:30 PM"
      ],
      valor: "15.000",
      destinos: ["Granada", "Cocorná", "El Carmen"]
    }
  ];

  return (
    <div className="container mx-auto py-8 px-4">
      <motion.h1 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-3xl font-bold mb-8 text-center"
      >
        Rutas de Transporte
      </motion.h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {rutas.map((ruta, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-lg shadow-lg overflow-hidden"
          >
            <div className="relative h-48">
              <img  
                className="w-full h-full object-cover" 
                alt={`Transporte ${ruta.empresa}`}
               src="https://images.unsplash.com/photo-1619240538722-3e27d5cf6e63" />
            </div>
            <div className="p-6">
              <h2 className="text-xl font-bold mb-4">{ruta.empresa}</h2>
              
              <div className="mb-4">
                <h3 className="font-semibold mb-2">Destinos:</h3>
                <ul className="list-disc list-inside text-gray-600">
                  {ruta.destinos.map((destino, dIndex) => (
                    <li key={dIndex}>{destino}</li>
                  ))}
                </ul>
              </div>

              <div className="mb-4">
                <h3 className="font-semibold mb-2">Horarios:</h3>
                {ruta.horarios.map((horario, hIndex) => (
                  <p key={hIndex} className="text-gray-600">{horario}</p>
                ))}
              </div>

              <div className="mt-4 pt-4 border-t border-gray-200">
                <p className="text-gray-600 mb-2">
                  <strong>Valor del pasaje:</strong> ${ruta.valor} COP
                </p>
                <p className="text-gray-600">
                  <strong>Contacto:</strong> {ruta.contacto}
                </p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default Transporte;
