
import React from 'react';
import { motion } from 'framer-motion';

const Restaurantes = () => {
  const restaurantes = [
    {
      nombre: "Sabores de San Luis",
      direccion: "Carrera 20 #15-30",
      telefono: "604-345-6789",
      correo: "saboresdesanluis@email.com",
      menus: ["Bandeja paisa", "Sancocho", "Ajiaco"]
    },
    {
      nombre: "El Rincón Antioqueño",
      direccion: "Calle 15 #10-25",
      telefono: "604-456-7890",
      correo: "rinconantioqueno@email.com",
      menus: ["Frijoles", "Mondongo", "Cazuela de mariscos"]
    }
  ];

  return (
    <div className="container mx-auto py-8 px-4">
      <motion.h1 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-3xl font-bold mb-8 text-center"
      >
        Restaurantes en San Luis
      </motion.h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {restaurantes.map((restaurante, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-lg shadow-lg overflow-hidden"
          >
            <div className="relative h-64">
              <img  
                className="w-full h-full object-cover" 
                alt={`Restaurante ${restaurante.nombre}`}
               src="https://images.unsplash.com/photo-1565368278738-5b36a804ae18" />
            </div>
            <div className="p-6">
              <h2 className="text-2xl font-bold mb-4">{restaurante.nombre}</h2>
              <p className="text-gray-600 mb-2">
                <strong>Dirección:</strong> {restaurante.direccion}
              </p>
              <p className="text-gray-600 mb-2">
                <strong>Teléfono:</strong> {restaurante.telefono}
              </p>
              <p className="text-gray-600 mb-4">
                <strong>Correo:</strong> {restaurante.correo}
              </p>
              
              <h3 className="text-xl font-semibold mb-3">Menú Destacado</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {restaurante.menus.map((menu, menuIndex) => (
                  <div key={menuIndex} className="relative">
                    <img  
                      className="w-full h-32 object-cover rounded-lg" 
                      alt={`Plato ${menu}`}
                     src="https://images.unsplash.com/photo-1559229475-bf6dadb506a1" />
                    <p className="mt-2 text-center font-medium">{menu}</p>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default Restaurantes;
